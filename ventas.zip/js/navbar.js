const navbar = document.getElementById('navbar');
function quitarNavbar(){
    navbar.classList.toggle('active');
}